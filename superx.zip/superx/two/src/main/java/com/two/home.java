package com.two;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class home extends Application {

    @Override
    public void start(Stage widgetStage) throws Exception {
      Text username=new Text();
      Text user=new Text("username"); 
      TextField userTextField=new TextField();
      userTextField.setFocusTraversable(false);  
      userTextField.setPromptText("Enter your name");

      Text password=new Text();
      Text pass=new Text("password");
      PasswordField passwordField=new PasswordField();
      passwordField.setFocusTraversable(false);
      passwordField.setPromptText("Enter password");

      Button submit=new Button("Submit");
      submit.setOnAction(new EventHandler<ActionEvent>() {

        @Override
        public void handle(ActionEvent arg0) {
           username.setText(userTextField.getText());
           password.setText(passwordField.getText());
        }
    
      });
      GridPane gp=new GridPane();
      gp.setHgap(10);
      gp.setVgap(10);
      for(int i=0;i<10;i++){
        for(int j=0;j<50;j++){
            gp.add(new Text("core2web"),i,j);
        }
      }

      VBox vb=new VBox(10,user,userTextField,pass,passwordField,submit,username,password,gp);
      vb.setPadding(new Insets(50,50,50,50));
      ScrollPane scrollPane=new ScrollPane(vb);
      Scene sc=new Scene(scrollPane,800,500);
      widgetStage.setScene(sc);
      widgetStage.show();

    }
    
}