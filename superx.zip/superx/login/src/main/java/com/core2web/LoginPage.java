package com.core2web;



import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class LoginPage extends Application {

    Stage primaryStage;
    Scene loginScene,detailsScene;
    Info data;



    @Override
    public void start(Stage stage){



        Text txt = new Text("Login to Core2Web");
        TextField tf1 = new TextField();
        tf1.setPromptText("enter username");
        TextField tf2 = new TextField();
        tf2.setPromptText("enter password");


        Button login = new Button("login");
        login.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent arg0) {

                 data = new Info(tf1.getText(),tf2.getText());
                initialize(data);
                primaryStage.setScene(detailsScene);

                
            }
            
        });


        VBox vb = new VBox(50,txt,tf1,tf2,login);
        vb.setStyle("-fx-background-color:lightblue");
        Scene sc = new Scene(vb,500,500);
        loginScene = sc;
        primaryStage = stage;
        vb.setAlignment(Pos.CENTER);
        stage.setScene(sc);
        stage.show();


        
    }

public void back(){

    primaryStage.setScene(loginScene);

}
    
    private void initialize(Info info){
        Details det = new Details();

        VBox  vb = det.createScene(this::back,info);
        vb.setAlignment(Pos.CENTER);
        
        detailsScene = new Scene(vb,500,500);

    }

    
   
    
}
