
package com.resume;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class home extends Application {

    @Override
    public void start(Stage myStage) {
        // Title: Introduction
        Text t4 = new Text("Introduction:");
        t4.setFont(new Font(36));
        t4.setFill(Color.PURPLE);
        t4.setStyle("-fx-stroke: black");
        t4.setEffect(new DropShadow(2, Color.YELLOW));

        // Contact Details
        Text t1 = new Text("Name: Vaibhavi");
        Text t2 = new Text("Number:702");
        Text t3 = new Text("Email:vaibhavirathod702@gmail.com ");
        t1.setFont(new Font(16));
        t2.setFont(new Font(16));
        t3.setFont(new Font(16));
        VBox vb1 = new VBox(8, t4, t1, t2, t3);
        vb1.setAlignment(Pos.CENTER_LEFT);
        vb1.setPadding(new Insets(10));

        // Profile Image
        Image image = new Image("file:assets/virat.jpeg"); // Load from local folder
        ImageView imageView = new ImageView(image);
        imageView.setFitHeight(160);
        imageView.setPreserveRatio(true);
        VBox vb2 = new VBox(imageView);
        vb2.setAlignment(Pos.CENTER_LEFT);
        vb2.setPadding(new Insets(10));

        HBox hb1 = new HBox(15, vb2, vb1);
        hb1.setAlignment(Pos.CENTER_LEFT);
        hb1.setPadding(new Insets(10));

        // Skills Section
        Text t5 = new Text("Skills");
        t5.setFill(Color.PURPLE);
        t5.setFont(new Font(36));
        t5.setStyle("-fx-stroke: black");
        t5.setEffect(new DropShadow(2, Color.PURPLE));

        Text t6 = new Text("C Language");
        Text t7 = new Text("C++");
        Text t8 = new Text("Java");
        Text t9 = new Text("Dart");
        Text t10 = new Text("Flutter");
        Text t11 = new Text("DSA");
        Text t12 = new Text("OOP");

        t6.setFont(new Font(16));
        t7.setFont(new Font(16));
        t8.setFont(new Font(16));
        t9.setFont(new Font(16));
        t10.setFont(new Font(16));
        t11.setFont(new Font(16));
        t12.setFont(new Font(16));

        HBox skillRow1 = new HBox(12, t6, t7, t8, t9, t10, t11, t12);
        skillRow1.setAlignment(Pos.CENTER_LEFT);

        VBox v5 = new VBox(8, t5, skillRow1);
        v5.setPadding(new Insets(10));

        // Education Section
        Text text1 = new Text("Education:");
        text1.setFill(Color.PURPLE);
        text1.setFont(new Font(36));
        text1.setStyle("-fx-stroke: black");
        text1.setEffect(new DropShadow(2, Color.YELLOW));

        Text tx2 = new Text("College : SKN");
        Text tx3 = new Text("Course  : BE in ");
        Text tx4 = new Text("2022-2026");
        Text tx5 = new Text("Grade : /9.00");

        tx2.setFont(new Font(16));
        tx3.setFont(new Font(16));
        tx4.setFont(new Font(16));
        tx5.setFont(new Font(16));

        VBox vBox1 = new VBox(8, text1, tx2, tx3, tx4, tx5);
        vBox1.setPadding(new Insets(10));

        // Project Section
        Text project = new Text("Projects");
        project.setFont(new Font(36));
        project.setFill(Color.PURPLE);
        project.setStyle("-fx-stroke: black");
        project.setEffect(new DropShadow(2, Color.YELLOW));

        Text ptext1 = new Text("Title : ");
        ptext1.setFont(new Font(16));

        Text desc = new Text("Description: ");
        desc.setFont(new Font(16));
        desc.setWrappingWidth(950);

        VBox pt = new VBox(10, project, ptext1, desc);
        pt.setPadding(new Insets(10));

        // Root Container
        VBox v6 = new VBox(15, hb1, v5, vBox1, pt);
        v6.setPadding(new Insets(15));
        v6.setStyle("-fx-background-color: #f9f9f9;");

        Scene MyScene = new Scene(v6, 1000, 800);

        myStage.setTitle("Resume");
        myStage.setScene(MyScene);
        myStage.setResizable(true);
        myStage.getIcons().add(image); // Optional: sets app icon
        myStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}