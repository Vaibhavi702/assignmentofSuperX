package com.fivebutton;

public class EventHandler<T> {

}
