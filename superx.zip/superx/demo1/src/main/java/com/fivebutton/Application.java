package com.fivebutton;

public class Application {

    public static void launch(Class<Home> class1, String[] args) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'launch'");
    }

}
