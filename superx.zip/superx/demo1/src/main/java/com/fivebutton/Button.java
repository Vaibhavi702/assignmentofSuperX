package com.fivebutton;

public class Button {

    public void setOnAction(EventHandler<ActionEvent> eventHandler) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'setOnAction'");
    }

}
