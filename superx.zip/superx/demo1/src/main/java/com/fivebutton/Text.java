package com.fivebutton;

public class Text {

}
