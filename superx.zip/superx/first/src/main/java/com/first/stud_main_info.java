package com.first;




public class stud_main_info {
    
    private String studentName;
    private String studentRollNo;
    public String getStudentName() {
        return studentName;
    }
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    public String getStudentRollNo() {
        return studentRollNo;
    }
    public void setStudentRollNo(String studentRollNo) {
        this.studentRollNo = studentRollNo;
    }
    

}